function validatesignupForm() {
    var x = document.forms['sign-up-form']['txtFname'];
    var y = x.value;
    if (y == "") {
        alert('Please Type First Name');
        x.focus();
        return false;
    }
    var reg = /^[ a-zA-Z]*$/;
    if (reg.test(y) == false) {
        alert('Invalid First Name! Please Enter only Alphabets');
        x.focus();
        return false;
    }
    var x = document.forms['sign-up-form']['txtlname'];
    var y = x.value;
    if (y == "") {
        alert('Please Type Last Name');
        x.focus();
        return false;
    }
    var reg = /^[ a-zA-Z]*$/;
    if (reg.test(y) == false) {
        alert('Invalid Last Name! Please Enter only Alphabets');
        x.focus();
        return false;
    }
    var x = document.forms['sign-up-form']['txtuname'];
    var y = x.value;
    if (y == "") {
        alert('Please Type Username');
        x.focus();
        return false;
    }
    var reg = /^[ a-zA-Z0-9]*$/;
    if (reg.test(y) == false) {
        alert('Invalid Username! Please Enter only Alphabets');
        x.focus();
        return false;
    }
    var x = document.forms['sign-up-form']['psw'];
    var y = x.value;
    if (y == "") {
        alert('Please Type Password');
        x.focus();
        return false;
    }
    var reg = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
    if (reg.test(y) == false) {
        alert('Invalid Password! Please Enter password between 8 to 15 characters which contain at least one lowercase letter, one uppercase letter, one numeric digit, and one special character');
        x.focus();
        return false;
    }
    
}
function validateSignInForm(){
    var x = document.forms['sign-in-form']['txtuname'];
    var y = x.value;
    if (y == "") {
        alert('Please Type Username');
        x.focus();
        return false;
    }
    var reg = /^[ a-zA-Z0-9]*$/;
    if (reg.test(y) == false) {
        alert('Invalid Username! Please Enter only Alphabets');
        x.focus();
        return false;
    }
    var x = document.forms['sign-in-form']['psw'];
    var y = x.value;
    if (y == "") {
        alert('Please Type Password');
        x.focus();
        return false;
    }
    var reg = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
    if (reg.test(y) == false) {
        alert('Invalid Password! Please Enter password between 8 to 15 characters which contain at least one lowercase letter, one uppercase letter, one numeric digit, and one special character');
        x.focus();
        return false;
    }
}