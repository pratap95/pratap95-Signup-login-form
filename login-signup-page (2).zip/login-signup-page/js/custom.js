// Flip input fields
$('#sign-up .field input').blur(function () {
    $('#sign-up .field input').each(function () {
        $this = $(this);
        if ( this.value != '' ) {
          $this.addClass('focused');
          $('.field input + label + span').css({'opacity': 1});
        }
        else {
          $this.removeClass('focused');
          $('.field input + label + span').css({'opacity': 0});
        }
    });
});
$('#sign-in .field input').blur(function () {
    $('#sign-in .field input').each(function () {
        $this = $(this);
        if ( this.value != '' ) {
          $this.addClass('focused');
          $('.field input + label + span').css({'opacity': 1});
        }
        else {
          $this.removeClass('focused');
          $('.field input + label + span').css({'opacity': 0});
        }
    });
});
// Password show hide
        function Toggle() { 
            var temp = document.getElementById("pass"); 
            if (temp.type === "password") { 
                temp.type = "text"; 
            } 
            else { 
                temp.type = "password"; 
            } 
        } 

        //Animation initizlize
        AOS.init();