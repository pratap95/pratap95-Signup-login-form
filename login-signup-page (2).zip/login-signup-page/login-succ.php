<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/style.css">
    <title>Login Success</title>
</head>
<body>
<div class="sign-up-wrapper"></div>
    <div class="sign-up-form">
<?php
include("data-con.php");
extract($_POST);

if(isset($submit))
{
	$rs=mysqli_query($conn,"select * from userdlts where Username='$txtuname' and pass='$psw'");
	if(mysqli_num_rows($rs)<1)
	{
		$found="N";
	}
	else
	{
		$_SESSION["Username"]=$txtuname;
	}
}
if (isset($_SESSION["Username"]))
{
echo "<div class='footer-info text-center'>Hye you are sucessfully login!!!</div>";
echo "<div class='footer-info text-center'><a href=index.php>Continue to signup</a></div>";
exit;
}
?>
</div>
</div>
</body>
</html>