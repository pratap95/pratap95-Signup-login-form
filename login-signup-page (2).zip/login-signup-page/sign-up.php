
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Signup Alert</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="sign-up-wrapper"></div>
    <div class="sign-up-form">
           
<?php

extract($_POST);
include("data-con.php");
$rs=mysqli_query($conn,"select * from userdlts where Username='$txtuname'");
if (mysqli_num_rows($rs)>0)
{
    echo "<div class='footer-info text-center'>Username Already Exists</div>";
    echo "<div class='footer-info text-center'><a href='index.php'>Click here to retry</a></div>";
	exit;
}
$query="INSERT INTO userdlts (First_Name, Last_Name, Username, pass)
            VALUES ('$txtFname','$txtlname','$txtuname','$psw')";
$rs=mysqli_query($conn,$query);
echo "<div class='footer-info text-center'>Your Username  $txtuname Created Sucessfully</div>";
echo "<div class='footer-info text-center'>Please Login using your Username and Password</div>";
echo "<div class='footer-info text-center'><a href=login.php>Login</a></div>";


?>
</div>
</div>
</body>
</html>