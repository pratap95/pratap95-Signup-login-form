<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/style.css">
    <title>Signup Page</title>
</head>

<body>
    <div class="sign-up-wrapper"></div>
    <div class="sign-up-form">
        <div class="user-div text-center"><i class="far fa-user"></i></div>
        <form data-aos="fade-left" id="sign-up" name="sign-up-form" class="contact flp" method="post" action="sign-up.php" onsubmit="return validatesignupForm();">
            <h1>User Signup</h1>
            <div class="field name-box">
                <input type="text" id="fname" name="txtFname" maxlength="60" placeholder="Type First Name..." />
                <label for="fname">First Name
                    <span class="red-star">*</span>
                </label>
            </div>
            <div class="field name-box">
                <input type="text" id="lname" name="txtlname" maxlength="60" placeholder="Type Last Name..." />
                <label for="lname">Last Name
                    <span class="red-star">*</span>
                </label>
            </div>
            <div class="field name-box">
                <input type="text" id="uname" name="txtuname" maxlength="60" placeholder="Type Username..." />
                <label for="uname">Username
                    <span class="red-star">*</span>
                </label>
            </div>
            <div class="field msg-box">
                <input type="password" id="pass" name="psw" placeholder="Type Password..." maxlength="15">
                <label for="pass">Password
                    <span class="red-star">*</span>
                </label>
            </div>
            <input type="checkbox" onclick="Toggle()">  <b style=color:#fff>Show Password</b> 
            <div class="text-center">
                <input type="submit" name="submit" value="Signup">
                <input type="reset" name="reset" value="Reset">
            </div>
        </form>
        <div class="footer-info text-center">
        <p>Already a member? <a href="login.php">Click here to sign in</a></p>
    </div>
    </div>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/font-awesome.js"></script>
    <script src="js/validate.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>